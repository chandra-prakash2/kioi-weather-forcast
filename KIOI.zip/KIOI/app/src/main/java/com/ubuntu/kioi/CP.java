package com.ubuntu.kioi;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class CP extends AppCompatActivity {

    Button b1;
    EditText t1,t2,t3,t4;
    TextView tv1,tv2,tv3,tv4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cp);

        b1=(Button)findViewById(R.id.button31);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i;
                i=new Intent(CP.this,cp_submit.class);
                startActivity(i);
            }
        });

/*
        t1=(EditText)findViewById(R.id.editText7);
        t2=(EditText)findViewById(R.id.editText10);
        t3=(EditText)findViewById(R.id.editText9);
        t4=(EditText)findViewById(R.id.editText6);

        tv1=(TextView)findViewById(R.id.textView16);
        tv2=(TextView)findViewById(R.id.textView17);
        tv3=(TextView)findViewById(R.id.textView25);
        tv4=(TextView)findViewById(R.id.textView24);

        tv1.setText(t1.getText());
        tv2.setText(t2.getText());
        tv3.setText(t3.getText());
        tv4.setText(t4.getText());
*/
    }
}
