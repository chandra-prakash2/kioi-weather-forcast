package com.ubuntu.kioi;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class CSQ extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_csq);
    }
}
