package com.ubuntu.kioi;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Login extends AppCompatActivity {

    Button b1,b2,b3,b4,b5,b6,b7;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        b1=(Button)findViewById(R.id.button7);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i;
                i=new Intent(Login.this,WI.class);
                startActivity(i);
            }
        });

        b2=(Button)findViewById(R.id.button15);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i;
                i=new Intent(Login.this,Empty.class);
                startActivity(i);
            }
        });

        b3=(Button)findViewById(R.id.button4);
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i;
                i=new Intent(Login.this,CS.class);
                startActivity(i);
            }
        });

        b4=(Button)findViewById(R.id.button3);
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i;
                i=new Intent(Login.this,CPG.class);
                startActivity(i);
            }
        });

        b5=(Button)findViewById(R.id.button6);
        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i;
                i=new Intent(Login.this,EF.class);
                startActivity(i);
            }
        });

        b6=(Button)findViewById(R.id.button5);
        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i;
                i=new Intent(Login.this,CSQ.class);
                startActivity(i);
            }
        });

        b7=(Button)findViewById(R.id.button8);
        b7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i;
                i=new Intent(Login.this,AAC.class);
                startActivity(i);
            }
        });





    }
}
