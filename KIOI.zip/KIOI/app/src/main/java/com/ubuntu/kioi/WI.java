package com.ubuntu.kioi;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import java.util.Calendar;

public class WI extends AppCompatActivity {

    int temp=21;
    int temp2,temp3,temp4;
    TextView t1;
    Button b1,b2,b3,b4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wi);

        t1=(TextView)findViewById(R.id.textView6);
        t1.setText("21");


        Calendar cal = Calendar.getInstance();

        b1=(Button)findViewById(R.id.button9);
        b2=(Button)findViewById(R.id.button10);
        b3=(Button)findViewById(R.id.button11);
        b4=(Button)findViewById(R.id.button12);

        String s1,s2,s3,s4,day,day2;

        if(Calendar.DAY_OF_WEEK==1+2)
        {
            day="Sunday ";
            day2="Monday ";
        }
        else if(Calendar.DAY_OF_WEEK==2+2)
        {
            day="Monday ";
            day2="Tuesday ";
        }
        else if(Calendar.DAY_OF_WEEK==3+2)
        {
            day="Tuesday ";
            day="Wednesday ";
        }
        else if(Calendar.DAY_OF_WEEK==4+2)
        {
            day="Wednesday ";
            day2="Thursday ";
        }
        else if(Calendar.DAY_OF_WEEK==5+2)
        {
            day="Thursday ";
            day2="Friday ";
        }
        else if(Calendar.DAY_OF_WEEK==1)
        {
            day="Friday ";
            day2="Saturday ";
        }
        else if(Calendar.DAY_OF_WEEK==2)
        {
            day="Saturday ";
            day2="Sunday ";
        }

        s1="Today\t\t"+Calendar.DATE+"/"+Calendar.MONTH+"/"+Calendar.YEAR;
        s2="Tomorrow\t\t"+(Calendar.DATE+1)+"/"+Calendar.MONTH+"/"+Calendar.YEAR;
        s3=day+"\t\t"+(Calendar.DATE+2)+"/"+Calendar.MONTH+"/"+Calendar.YEAR;
        s4=day2+"\t\t"+(Calendar.DATE+3)+"/"+Calendar.MONTH+"/"+Calendar.YEAR;

        b1.setText(s1);
        // b1.setRight(temp);
        b2.setText(s2+"\t\t"+temp2);
        b3.setText(s3+"\t\t"+temp3);
        b4.setText(s4+"\t\t"+temp4);

    }
}
